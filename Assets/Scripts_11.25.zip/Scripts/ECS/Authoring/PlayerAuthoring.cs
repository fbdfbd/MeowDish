using UnityEngine;
using Unity.Entities;
using Unity.Collections;
using Unity.Mathematics;
using Meow.ECS.Components; // ���δ� ���ӽ����̽�

namespace Meow.ECS.Authoring
{
    public class PlayerAuthoring : MonoBehaviour
    {
        [Header("Data Source")]
        public UnitBaseStatsSO BaseStats; // SO ����

        class Baker : Baker<PlayerAuthoring>
        {
            public override void Bake(PlayerAuthoring authoring)
            {
                Debug.Log($"[Baker] PlayerAuthoring Bake ����: {authoring.name}");
                Entity entity = GetEntity(TransformUsageFlags.Dynamic);

                if (authoring.BaseStats == null)
                {
                    Debug.LogError($"SO�� �����ϴ�. {authoring.name}");
                    return;
                }

                // 1. BlobAsset ���� (SO -> Blob)
                using (var builder = new BlobBuilder(Allocator.Temp))
                {
                    ref UnitBaseStatBlob blobRoot = ref builder.ConstructRoot<UnitBaseStatBlob>();

                    // SO �����͸� Blob�� ����
                    blobRoot.BaseMoveSpeed = authoring.BaseStats.BaseMoveSpeed;

                    var blobRef = builder.CreateBlobAssetReference<UnitBaseStatBlob>(Allocator.Persistent);
                    AddBlobAsset(ref blobRef, out var hash);

                    // UnitConfig ������Ʈ �߰�
                    AddComponent(entity, new UnitConfig { BlobRef = blobRef });
                }

                // 2. �±� �߰�
                AddComponent(entity, new PlayerTag());

                // 3. ���� ����(Stats) �ʱ�ȭ
                AddComponent(entity, new PlayerWorkStats
                {
                    MoveSpeed = 1.0f, // �����̹Ƿ� 1.0 ����
                    GlobalInteractSpeed = 1.0f,
                    ChopSpeedMultiplier = authoring.BaseStats.InitialChopSpeed,
                    GrillSpeedMultiplier = authoring.BaseStats.InitialGrillSpeed,
                    WashSpeedMultiplier = 1.0f
                });

                // 4. ����(�ִϸ��̼ǰ� ����?) �ʱ�ȭ
                AddComponent(entity, new PlayerStateComponent
                {
                    CurrentState = PlayerActionState.Idle
                });

                // 5. ��ȣ�ۿ� ������ �ʱ�ȭ
                AddComponent(entity, new InteractionData
                {
                    TargetStation = Entity.Null,
                    FacingDirection = new float2(0, 1)// �⺻ ����
                });

                // 6. ����ִ� ������
                AddComponent(entity, new PlayerHeldItem
                {
                    HeldItem = Entity.Null
                });

                // 7. �۾� Ÿ�̸�
                AddComponent(entity, new WorkTimerComponent
                {
                    IsWorking = false,
                    CurrentProgress = 0,
                    RequiredTime = 0
                });
            }
        }
    }
}