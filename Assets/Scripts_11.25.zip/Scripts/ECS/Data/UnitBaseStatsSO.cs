using UnityEngine;

[CreateAssetMenu(menuName = "Meow/UnitBaseStats")]
public class UnitBaseStatsSO : ScriptableObject
{
    [Header("�Һ� ������(Blob)")]
    public float BaseMoveSpeed = 5.0f;

    [Header("�⺻ ����")]
    public float InitialChopSpeed = 1.0f;
    public float InitialGrillSpeed = 1.0f;
}