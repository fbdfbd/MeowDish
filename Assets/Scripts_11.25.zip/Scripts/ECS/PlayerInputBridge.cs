using UnityEngine;
using UnityEngine.InputSystem;
using Unity.Entities;
using Unity.Mathematics;
using Meow.ECS.Components;

public class PlayerInputBridge : MonoBehaviour
{
    private EntityManager em;
    private Entity playerEntity;

    void Awake()
    {
        em = World.DefaultGameObjectInjectionWorld.EntityManager;
        playerEntity = Entity.Null;
    }

    void Update()
    {
        // ���� �� ã������ �� �� �õ�
        if (playerEntity == Entity.Null)
        {
            using var query = em.CreateEntityQuery(typeof(PlayerTag));
            if (!query.IsEmpty)
            {
                playerEntity = query.GetSingletonEntity();
                Debug.Log($"PlayerInputBridge: PlayerTag ��ƼƼ ����� = {playerEntity.Index}");
            }
        }
    }

    void OnMove(InputValue value)
    {
        if (playerEntity == Entity.Null || !em.Exists(playerEntity))
            return; // ���� ��ƼƼ ������ �Է� ����

        Vector2 v = value.Get<Vector2>();
        if (v.sqrMagnitude > 0.0001f)
            v = v.normalized;
        else
            v = Vector2.zero;

        var interaction = em.GetComponentData<InteractionData>(playerEntity);
        interaction.FacingDirection = new float2(v.x, v.y);
        em.SetComponentData(playerEntity, interaction);
    }
}
