using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using Meow.ECS.Components;


namespace Meow.ECS.System
{
    [BurstCompile]
    public partial struct PlayerMoveSystem : ISystem
    {
        public void OnUpdate(ref SystemState state)
        {
            float dt = SystemAPI.Time.DeltaTime;

            foreach (var (interaction, unitConfig, workStats, playerState, transform)
                     in SystemAPI.Query<
                            RefRO<InteractionData>,
                            RefRO<UnitConfig>,
                            RefRO<PlayerWorkStats>,
                            RefRW<PlayerStateComponent>,
                            RefRW<LocalTransform>>()
                         .WithAll<PlayerTag>())
            {
                // �۾� ��/�����̸� �̵�/���� �� �� �ǵ��� ����
                if (playerState.ValueRO.CurrentState == PlayerActionState.Working ||
                    playerState.ValueRO.CurrentState == PlayerActionState.Stunned)
                    continue;

                float2 dir2D = interaction.ValueRO.FacingDirection;

                // �Է� ���� �� Idle��
                if (math.lengthsq(dir2D) < 0.0001f)
                {
                    if (playerState.ValueRO.CurrentState != PlayerActionState.Idle)
                    {
                        playerState.ValueRW.CurrentState = PlayerActionState.Idle;
                    }
                    continue;
                }

                // ���� �̵�
                float3 dir = new float3(dir2D.x, 0, dir2D.y);

                float baseSpeed = unitConfig.ValueRO.BlobRef.Value.BaseMoveSpeed;
                float speed = baseSpeed * workStats.ValueRO.MoveSpeed;

                transform.ValueRW.Position += dir * speed * dt;

                // �̵� ���̸� Moving����
                if (playerState.ValueRO.CurrentState != PlayerActionState.Moving)
                {
                    playerState.ValueRW.CurrentState = PlayerActionState.Moving;
                }
            }
        }
    }
}