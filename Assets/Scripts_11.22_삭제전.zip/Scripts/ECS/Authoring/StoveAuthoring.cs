using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Meow.ECS.Components;

namespace Meow.ECS.Authoring
{
    public class StoveAuthoring : MonoBehaviour
    {
        [Header("�����̼� ����")]
        public int stationID = 0;

        [Header("���� ����")]
        public float cookDuration = 5f;  // 5�� ����
        public float burnDuration = 8f;  // 8�� ������ ź ������ ó��

        [Header("�ݶ��̴� ũ�� (ǥ�ÿ�)")]
        public Vector3 colliderSize = new Vector3(1.5f, 1f, 1.5f);

        private Entity _stoveEntity;
        private EntityManager _entityManager;

        private void Start()
        {
            var world = World.DefaultGameObjectInjectionWorld;

            if (world == null || !world.IsCreated)
            {
                Debug.LogError("[Stove] World ����!");
                return;
            }

            _entityManager = world.EntityManager;
            _stoveEntity = _entityManager.CreateEntity();

            var position = transform.position;

            _entityManager.AddComponentData(_stoveEntity,
                LocalTransform.FromPosition(position));

            _entityManager.AddComponentData(_stoveEntity, new LocalToWorld
            {
                Value = float4x4.TRS(position, quaternion.identity, new float3(1))
            });

            _entityManager.AddComponentData(_stoveEntity, new StationComponent
            {
                Type = StationType.Stove,
                StationID = stationID,
                PlacedItemEntity = Entity.Null
            });

            _entityManager.AddComponent<StoveStationTag>(_stoveEntity);

            _entityManager.AddComponentData(_stoveEntity, new StoveComponent
            {
                CookDuration = cookDuration,
                BurnDuration = burnDuration
            });

            _entityManager.AddComponentData(_stoveEntity, new InteractableComponent
            {
                IsActive = true
            });
        }

        private void LateUpdate()
        {
            if (_entityManager.Exists(_stoveEntity))
            {
                var lt = _entityManager.GetComponentData<LocalTransform>(_stoveEntity);
                transform.position = lt.Position;
            }
        }

        private void OnDestroy()
        {
            if (World.DefaultGameObjectInjectionWorld == null ||
                !World.DefaultGameObjectInjectionWorld.IsCreated)
                return;

            var em = World.DefaultGameObjectInjectionWorld.EntityManager;

            if (em.Exists(_stoveEntity))
            {
                em.DestroyEntity(_stoveEntity);
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireCube(transform.position, colliderSize);
        }
    }
}
