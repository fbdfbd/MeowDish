using Unity.Entities;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Meow.ECS.Components;

namespace Meow.ECS.Authoring
{
    public class ContainerAuthoring : MonoBehaviour
    {
        [Header("�����̳� ����")]
        public IngredientType providedIngredient = IngredientType.Bread;
        public bool allowReturn = true;
        public bool isInfinite = true;

        [Header("�����̼� ����")]
        public int stationID = 0;

        [Header("�ݶ��̴� ũ��")]
        public Vector3 colliderSize = new Vector3(1.5f, 2f, 1.5f);

        private Entity _containerEntity;
        private EntityManager _entityManager;

        private void Start()
        {
            var world = World.DefaultGameObjectInjectionWorld;

            if (world == null || !world.IsCreated)
            {
                Debug.LogError("[Container] World ����!");
                return;
            }

            _entityManager = world.EntityManager;
            _containerEntity = _entityManager.CreateEntity();

            var position = transform.position;

            // 1. LocalTransform
            _entityManager.AddComponentData(_containerEntity,
                LocalTransform.FromPosition(position));

            // 2. LocalToWorld
            _entityManager.AddComponentData(_containerEntity, new LocalToWorld
            {
                Value = float4x4.TRS(position, quaternion.identity, new float3(1))
            });

            // 3. StationComponent
            _entityManager.AddComponentData(_containerEntity, new StationComponent
            {
                Type = StationType.Container,
                StationID = stationID,
                PlacedItemEntity = Entity.Null
            });

            // 4. ContainerComponent
            _entityManager.AddComponentData(_containerEntity, new ContainerComponent
            {
                ProvidedIngredient = providedIngredient,
                AllowReturn = allowReturn,
                IsInfinite = isInfinite
            });

            // 5. InteractableComponent (���� �Ÿ� ���� ����)
            _entityManager.AddComponentData(_containerEntity, new InteractableComponent
            {
                IsActive = true
            });

            // 6. PhysicsCollider (Box)
            var boxGeometry = new BoxGeometry
            {
                Center = float3.zero,
                Orientation = quaternion.identity,
                Size = new float3(colliderSize.x, colliderSize.y, colliderSize.z),
                BevelRadius = 0.05f
            };

            var collider = Unity.Physics.BoxCollider.Create(
                boxGeometry,
                new CollisionFilter
                {
                    BelongsTo = 1u << 6,
                    CollidesWith = ~0u,
                    GroupIndex = 0
                }
            );

            _entityManager.AddComponentData(_containerEntity, new PhysicsCollider
            {
                Value = collider
            });

            // 7. PhysicsVelocity
            _entityManager.AddComponentData(_containerEntity, new PhysicsVelocity
            {
                Linear = float3.zero,
                Angular = float3.zero
            });

            // 8. PhysicsMass (Kinematic)
            _entityManager.AddComponentData(_containerEntity,
                PhysicsMass.CreateKinematic(MassProperties.UnitSphere));

            // 9. Simulate �÷���
            _entityManager.AddComponent<Simulate>(_containerEntity);

            // 10. PhysicsWorldIndex
            _entityManager.AddSharedComponent(_containerEntity, new PhysicsWorldIndex(0));
        }

        private void LateUpdate()
        {
            if (_entityManager.Exists(_containerEntity))
            {
                var lt = _entityManager.GetComponentData<LocalTransform>(_containerEntity);
                transform.position = lt.Position;
            }
        }

        private void OnDestroy()
        {
            if (World.DefaultGameObjectInjectionWorld == null ||
                !World.DefaultGameObjectInjectionWorld.IsCreated)
                return;

            var em = World.DefaultGameObjectInjectionWorld.EntityManager;

            if (em.Exists(_containerEntity))
            {
                if (em.HasComponent<PhysicsCollider>(_containerEntity))
                {
                    var collider = em.GetComponentData<PhysicsCollider>(_containerEntity);
                    if (collider.Value.IsCreated)
                    {
                        collider.Value.Dispose();
                    }
                }

                em.DestroyEntity(_containerEntity);
            }
        }

        private void OnDrawGizmosSelected()
        {
            // ���� ��ȣ�ۿ� �ݰ� ������ ����, �ݶ��̴� ũ�⸸ �ð�ȭ
            Gizmos.color = Color.red;
            Gizmos.DrawWireCube(transform.position, colliderSize);
        }
    }
}
