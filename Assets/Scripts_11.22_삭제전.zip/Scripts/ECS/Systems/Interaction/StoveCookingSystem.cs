using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Meow.ECS.Components;

namespace Meow.ECS.Systems
{
    /// <summary>
    /// ����꿡�� ���� ���� (�⺻ ����: �����⸸, Ÿ�� �� ���߿�)
    /// </summary>
    [BurstCompile]
    [UpdateInGroup(typeof(SimulationSystemGroup))]
    public partial struct StoveCookingSystem : ISystem
    {
        [BurstCompile]
        public void OnCreate(ref SystemState state) { }

        [BurstCompile]
        public void OnDestroy(ref SystemState state) { }

        [BurstCompile]
        public void OnUpdate(ref SystemState state)
        {
            float dt = SystemAPI.Time.DeltaTime;
            var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);

            // ����� �����̼ǵ� ��ȸ
            foreach (var (station, entity) in
                     SystemAPI.Query<RefRO<StationComponent>>()
                         .WithAll<StoveStationTag>()
                         .WithEntityAccess())
            {
                Entity item = station.ValueRO.PlacedItemEntity;
                if (item == Entity.Null)
                    continue;

                // ���� ����� �ƴ� �������̸� ��ŵ
                if (!SystemAPI.HasComponent<CookableComponent>(item))
                    continue;

                var cookable = SystemAPI.GetComponent<CookableComponent>(item);

                // CookingState ������ �߰��ϰ� ���� �����Ӻ��� ó��
                if (!SystemAPI.HasComponent<CookingState>(item))
                {
                    ecb.AddComponent(item, new CookingState { Elapsed = 0f });
                    continue;
                }

                var cookState = SystemAPI.GetComponentRW<CookingState>(item);
                cookState.ValueRW.Elapsed += dt;

                float elapsed = cookState.ValueRO.Elapsed;

                // ���� ó��: RawTag �� CookedTag
                if (elapsed >= cookable.CookTime)
                {
                    if (SystemAPI.HasComponent<RawItemTag>(item))
                        ecb.RemoveComponent<RawItemTag>(item);

                    if (!SystemAPI.HasComponent<CookedItemTag>(item))
                        ecb.AddComponent<CookedItemTag>(item);
                }

                // Ÿ�� ó��(BurnTime, BurnableTag)�� ���߿� �߰��ص� ��
            }

            ecb.Playback(state.EntityManager);
            ecb.Dispose();
        }
    }
}
