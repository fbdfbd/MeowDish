using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Transforms;
using Meow.ECS.Components;
using Unity.Physics.Systems;

namespace Meow.ECS.Systems
{
    [BurstCompile]
    [UpdateInGroup(typeof(FixedStepSimulationSystemGroup))]
    [UpdateBefore(typeof(PhysicsSystemGroup))]
    public partial struct PlayerMovementSystem : ISystem
    {
        [BurstCompile]
        public void OnCreate(ref SystemState state)
        {
            state.RequireForUpdate<PlayerInputComponent>();
            state.RequireForUpdate<PhysicsWorldSingleton>(); // PhysicsWorld �ʿ�
        }

        [BurstCompile]
        public void OnUpdate(ref SystemState state)
        {
            float deltaTime = SystemAPI.Time.DeltaTime;

            var physicsWorldSingleton = SystemAPI.GetSingleton<PhysicsWorldSingleton>();
            var physicsWorld = physicsWorldSingleton.PhysicsWorld;

            foreach (var (transform,
                          physicsVelocity,
                          input,
                          stats,
                          playerState,
                          collider,
                          entity) in
                     SystemAPI.Query<
                         RefRW<LocalTransform>,
                         RefRW<PhysicsVelocity>,
                         RefRO<PlayerInputComponent>,
                         RefRO<PlayerStatsComponent>,
                         RefRW<PlayerStateComponent>,
                         RefRO<Unity.Physics.PhysicsCollider>>()  // PhysicsCollider ���� ����
                         .WithEntityAccess())
            {
                float2 moveInput = input.ValueRO.MoveInput;

                if (math.lengthsq(moveInput) > 0.001f)
                {
                    float3 moveDir = new float3(moveInput.x, 0, moveInput.y);
                    moveDir = math.normalize(moveDir);
                    float finalSpeed = stats.ValueRO.GetFinalMoveSpeed();

                    // �̵� ���� ���� (Raycast��)
                    playerState.ValueRW.LastMoveDirection = moveDir;

                    // �̹� �����ӿ� �̵��ϰ� ���� ��
                    float3 desiredMove = moveDir * finalSpeed * deltaTime;

                    // ----- unsafe ���� �ȿ��� ColliderCastInput ���� -----
                    unsafe
                    {
                        var castInput = new ColliderCastInput
                        {
                            Collider = collider.ValueRO.ColliderPtr,
                            Orientation = transform.ValueRO.Rotation,
                            Start = transform.ValueRO.Position,
                            End = transform.ValueRO.Position + desiredMove
                        };

                        if (physicsWorld.CastCollider(castInput, out var hit))
                        {
                            float3 hitNormal = hit.SurfaceNormal;

                            // �̵� ������ �� �������� ���� ���� ����
                            bool movingIntoWall = math.dot(moveDir, hitNormal) < 0f;

                            if (movingIntoWall)
                            {
                                // �� ������ ���� ��� �� �浹 ���������� �̵�
                                float allowedFraction = hit.Fraction - 0.01f;
                                allowedFraction = math.clamp(allowedFraction, 0f, 1f);

                                float3 safeMove = desiredMove * allowedFraction;
                                transform.ValueRW.Position += safeMove;

                                // ���� �� �پ ����
                                physicsVelocity.ValueRW.Linear = float3.zero;
                            }
                            else
                            {
                                // ������ �־����ų� ���� �̵��̸� �׳� ���
                                transform.ValueRW.Position += desiredMove;
                                physicsVelocity.ValueRW.Linear = desiredMove / deltaTime;
                            }
                        }
                        else
                        {
                            // �浹 ������ �״�� �̵�
                            transform.ValueRW.Position += desiredMove;
                            physicsVelocity.ValueRW.Linear = desiredMove / deltaTime;
                        }
                    }


                    physicsVelocity.ValueRW.Angular = float3.zero;

                    // ȸ��
                    quaternion targetRot = quaternion.LookRotation(moveDir, math.up());
                    transform.ValueRW.Rotation = math.slerp(
                        transform.ValueRO.Rotation,
                        targetRot,
                        stats.ValueRO.RotationSpeed * deltaTime
                    );
                }
                else
                {
                    physicsVelocity.ValueRW.Linear = float3.zero;
                    physicsVelocity.ValueRW.Angular = float3.zero;
                }
            }
        }
    }
}
