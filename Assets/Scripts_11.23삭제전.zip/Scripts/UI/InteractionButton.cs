using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;

namespace Meow.UI
{
    /// <summary>
    /// ��ȣ�ۿ� ��ư (Tap + Hold)
    /// </summary>
    public class InteractionButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        [Header("Settings")]
        [SerializeField] private Button button;
        [SerializeField] private float holdThreshold = 0.5f;

        [Header("Visual Feedback (Optional)")]
        [SerializeField] private Image buttonImage;
        [SerializeField] private Color normalColor = Color.white;
        [SerializeField] private Color pressedColor = Color.yellow;
        [SerializeField] private Color holdColor = Color.green;

        private bool _isPressed = false;
        private bool _isHolding = false;
        private float _pressStartTime = 0f;

        private bool _wasTappedThisFrame = false;
        private bool _wasHoldStartedThisFrame = false;

        private Coroutine _holdCheckCoroutine;

        private void Awake()
        {
            if (button == null)
            {
                button = GetComponent<Button>();
            }
        }

        private void LateUpdate()
        {
            // �� ������ �� �ʱ�ȭ (GetKeyDown ���)
            _wasTappedThisFrame = false;
            _wasHoldStartedThisFrame = false;
        }

        // ========================================
        // ��ư ������ ��
        // ========================================
        public void OnPointerDown(PointerEventData eventData)
        {
            _isPressed = true;
            _isHolding = false;
            _pressStartTime = Time.time;

            // �ð� �ǵ��
            if (buttonImage != null)
            {
                buttonImage.color = pressedColor;
            }

            // Ȧ�� üũ ����
            if (_holdCheckCoroutine != null)
            {
                StopCoroutine(_holdCheckCoroutine);
            }
            _holdCheckCoroutine = StartCoroutine(CheckHoldRoutine());

            Debug.Log("[InteractionButton] Button pressed");
        }

        // ========================================
        // ��ư ���� ��
        // ========================================
        public void OnPointerUp(PointerEventData eventData)
        {
            _isPressed = false;
            float pressDuration = Time.time - _pressStartTime;

            // Ȧ�� üũ ����
            if (_holdCheckCoroutine != null)
            {
                StopCoroutine(_holdCheckCoroutine);
                _holdCheckCoroutine = null;
            }

            // �ð� �ǵ��
            if (buttonImage != null)
            {
                buttonImage.color = normalColor;
            }

            // ========================================
            // Ȧ�� ���� �ƴϾ����� �� Tap!
            // ========================================
            if (!_isHolding && pressDuration < holdThreshold)
            {
                _wasTappedThisFrame = true;
                Debug.Log($"[InteractionButton] TAP! (duration: {pressDuration:F2}s)");
            }
            else if (_isHolding)
            {
                Debug.Log($"[InteractionButton] HOLD RELEASED (duration: {pressDuration:F2}s)");
            }

            _isHolding = false;
        }

        // ========================================
        // Ȧ�� üũ �ڷ�ƾ
        // ========================================
        private IEnumerator CheckHoldRoutine()
        {
            yield return new WaitForSeconds(holdThreshold);

            // ���� ������ ������ Ȧ�� ����!
            if (_isPressed)
            {
                _isHolding = true;
                _wasHoldStartedThisFrame = true;

                // �ð� �ǵ��
                if (buttonImage != null)
                {
                    buttonImage.color = holdColor;
                }

                Debug.Log("[InteractionButton] HOLD STARTED!");
            }
        }

        // ========================================
        // Public ������Ƽ
        // ========================================

        /// <summary>
        /// �̹� �����ӿ� ���ߴ°�? (ª�� ������)
        /// </summary>
        public bool WasTappedThisFrame => _wasTappedThisFrame;

        /// <summary>
        /// �̹� �����ӿ� Ȧ�尡 ���۵ƴ°�?
        /// </summary>
        public bool WasHoldStartedThisFrame => _wasHoldStartedThisFrame;

        /// <summary>
        /// ���� Ȧ�� ���ΰ�?
        /// </summary>
        public bool IsHolding => _isHolding;

        /// <summary>
        /// ���� ��ư�� ������ �ִ°�?
        /// </summary>
        public bool IsPressed => _isPressed;
    }
}