using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Meow.ECS.Components;

namespace Meow.ECS.Authoring
{
    public class PlayerAuthoring : MonoBehaviour
    {
        [Header("�⺻ ����")]
        public float BaseMoveSpeed = 5.0f;
        public float BaseActionSpeed = 1.0f;

        [Header("ȸ�� ����")]
        [Tooltip("ĳ���� ȸ�� �ӵ� (���� Ŭ���� ������ ȸ��)")]
        [Range(5f, 20f)]
        public float RotationSpeed = 10f;

        [Header("ĳ���� �� ����")]
        [Tooltip("ĳ���� ���� Forward ���� ���� (Y�� ȸ��)")]
        [Range(-180f, 180f)]
        public float ModelRotationOffset = 0f;

        [Header("�÷��̾� ID")]
        [Tooltip("��Ƽ�÷��̾�� ID (�̱��� 0)")]
        public int PlayerId = 0;

        private Entity _playerEntity;
        private EntityManager _entityManager;
        private float _rotationOffsetRadians;

        private void Start()
        {
            _entityManager = World.DefaultGameObjectInjectionWorld.EntityManager;
            _rotationOffsetRadians = math.radians(ModelRotationOffset);

            _playerEntity = _entityManager.CreateEntity();

            var position = transform.position;
            // LocalTransform �߰�
            _entityManager.AddComponentData(_playerEntity,
                LocalTransform.FromPosition(position));

            // LocalToWorld �߰�
            _entityManager.AddComponentData(_playerEntity, new LocalToWorld
            {
                Value = float4x4.TRS(position, quaternion.identity, new float3(1, 1, 1))
            });
            _entityManager.AddComponent<Simulate>(_playerEntity);

            // Input
            _entityManager.AddComponentData(_playerEntity, new PlayerInputComponent
            {
                MoveInput = float2.zero,
                InteractTapped = false,
                InteractHoldStarted = false,
                InteractHolding = false
            });

            // PlayerStateComponent
            _entityManager.AddComponentData(_playerEntity, new PlayerStateComponent
            {
                PlayerId = PlayerId,
                HeldItemEntity = Entity.Null,
                IsHoldingItem = false,
                CurrentStationEntity = Entity.Null,
                IsNearStation = false
            });

            // Stats
            _entityManager.AddComponentData(_playerEntity, new PlayerStatsComponent
            {
                BaseMoveSpeed = BaseMoveSpeed,
                BaseActionSpeed = BaseActionSpeed,
                RotationSpeed = RotationSpeed,
                MoveSpeedBonus = 0,
                ActionSpeedBonus = 0,
                MoveSpeedMultiplier = 1.0f,
                ActionSpeedMultiplier = 1.0f,
                AllSpeedMultiplier = 1.0f
            });

            // Animation
            _entityManager.AddComponentData(_playerEntity, new PlayerAnimationComponent
            {
                IsMoving = false
            });

            // Equipment
            _entityManager.AddComponentData(_playerEntity, new EquipmentSlots());

            // Buffers
            _entityManager.AddBuffer<PermanentUpgrade>(_playerEntity);
            _entityManager.AddBuffer<TemporaryBuff>(_playerEntity);


            // PhysicsCollider
            var playerCollider = Unity.Physics.SphereCollider.Create(
                new Unity.Physics.SphereGeometry
                {
                    Center = float3.zero,
                    Radius = 0.5f
                },
                new Unity.Physics.CollisionFilter
                {
                    BelongsTo = 1u << 0,    
                    CollidesWith = ~0u,     
                    GroupIndex = 0
                }
            );


            _entityManager.AddComponentData(_playerEntity, new Unity.Physics.PhysicsCollider
            {
                Value = playerCollider
            });

            // PhysicsVelocity
            _entityManager.AddComponentData(_playerEntity, new Unity.Physics.PhysicsVelocity
            {
                Linear = float3.zero,
                Angular = float3.zero
            });

            // ? PhysicsMass - Kinematic Body
            _entityManager.AddComponentData(_playerEntity, Unity.Physics.PhysicsMass.CreateKinematic(
                Unity.Physics.MassProperties.UnitSphere
            ));

            // PhysicsDamping - ���� ����
            _entityManager.AddComponentData(_playerEntity, new Unity.Physics.PhysicsDamping
            {
                Linear = 10f,
                Angular = 10f
            });

            // �߷� ����
            _entityManager.AddComponentData(_playerEntity, new Unity.Physics.PhysicsGravityFactor
            {
                Value = 0f
            });
        }

        private void LateUpdate()
        {
            if (_entityManager.Exists(_playerEntity))
            {
                var lt = _entityManager.GetComponentData<LocalTransform>(_playerEntity);
                transform.position = lt.Position;

                // ȸ�� ������ ����
                quaternion offsetRotation = quaternion.RotateY(_rotationOffsetRadians);
                transform.rotation = math.mul(lt.Rotation, offsetRotation);

                // �����: �÷��̾� ���� ǥ�� (�ɼ�)
#if UNITY_EDITOR
                var playerState = _entityManager.GetComponentData<PlayerStateComponent>(_playerEntity);
                if (playerState.IsNearStation)
                {
                    Debug.DrawLine(transform.position, transform.position + Vector3.up * 2f, Color.yellow);
                }
#endif
            }
        }

        // 1. OnDisable �޼��� �߰� (OnDestroy ����)
        private void OnDisable()
        {
            // Play Mode ���� �� �޸� ���� ������ ���� OnDisable���� ���� ����
            DisposePlayerResources();
        }

        // 2. OnDestroy�� DisposePlayerResources ȣ��� ����
        private void OnDestroy()
        {
            // OnDisable���� �̹� ����������, Ȥ�� �� ��츦 ����� �ٽ� ȣ��
            DisposePlayerResources();
        }

        // 3. ���� ���� ������ ���� �޼���� �и�
        private void DisposePlayerResources()
        {
            if (World.DefaultGameObjectInjectionWorld == null ||
                !World.DefaultGameObjectInjectionWorld.IsCreated)
                return;

            var em = World.DefaultGameObjectInjectionWorld.EntityManager;

            if (em.Exists(_playerEntity))
            {
                // Collider Dispose (�޸� ���� ����)
                if (em.HasComponent<Unity.Physics.PhysicsCollider>(_playerEntity))
                {
                    var collider = em.GetComponentData<Unity.Physics.PhysicsCollider>(_playerEntity);
                    if (collider.Value.IsCreated)
                    {
                        collider.Value.Dispose();
                    }
                }

                em.DestroyEntity(_playerEntity);
                _playerEntity = Entity.Null;  // �ߺ� Dispose ����
            }
        }

        // �����: �÷��̾� ���� �ð�ȭ
        private void OnDrawGizmos()
        {
            if (Application.isPlaying && _entityManager != null && _entityManager.Exists(_playerEntity))
            {
                var playerState = _entityManager.GetComponentData<PlayerStateComponent>(_playerEntity);

                // �÷��̾� ��ġ
                Gizmos.color = Color.blue;
                Gizmos.DrawWireSphere(transform.position, 0.5f);

                // ��� �ִ� ������ ǥ��
                if (playerState.IsHoldingItem)
                {
                    Gizmos.color = Color.green;
                    Vector3 itemPos = transform.position + Vector3.up * 1f + transform.forward * 0.5f;
                    Gizmos.DrawCube(itemPos, Vector3.one * 0.3f);
                }

                // ��ó �����̼� ���ἱ
                if (playerState.IsNearStation && _entityManager.Exists(playerState.CurrentStationEntity))
                {
                    var stationTransform = _entityManager.GetComponentData<LocalTransform>(playerState.CurrentStationEntity);
                    Gizmos.color = Color.yellow;
                    Gizmos.DrawLine(transform.position, stationTransform.Position);
                }

#if UNITY_EDITOR
                // ���� �ؽ�Ʈ
                Vector3 labelPos = transform.position + Vector3.up * 2.5f;
                string info = $"Player {PlayerId}";

                if (playerState.IsHoldingItem)
                    info += "\n?? Holding Item";
                if (playerState.IsNearStation)
                    info += "\n? Near Station";

                UnityEditor.Handles.Label(labelPos, info, new GUIStyle()
                {
                    alignment = TextAnchor.MiddleCenter,
                    normal = new GUIStyleState() { textColor = Color.cyan },
                    fontSize = 11,
                    fontStyle = FontStyle.Bold
                });
#endif
            }
        }

        private void OnDrawGizmosSelected()
        {
            // �������� �� �߰� ����
            if (Application.isPlaying && _entityManager != null && _entityManager.Exists(_playerEntity))
            {
                var stats = _entityManager.GetComponentData<PlayerStatsComponent>(_playerEntity);
            }
        }
    }
}