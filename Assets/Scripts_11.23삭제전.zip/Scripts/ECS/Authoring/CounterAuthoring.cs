using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Meow.ECS.Components;

namespace Meow.ECS.Authoring
{
    public class CounterAuthoring : MonoBehaviour
    {
        [Header("�����̼� ����")]
        public int stationID = 0;

        [Header("ī���� ����")]
        [Tooltip("�� ī���� ���� �÷��� �� �ִ� �ִ� ������ ����")]
        public int maxItems = 4; // 1�� �θ� 1ĭ ī����

        [Header("�ݶ��̴� ũ�� (ǥ�ÿ�)")]
        public Vector3 colliderSize = new Vector3(1.5f, 1f, 1.5f);

        private Entity _counterEntity;
        private EntityManager _entityManager;

        private void Start()
        {
            var world = World.DefaultGameObjectInjectionWorld;

            if (world == null || !world.IsCreated)
            {
                Debug.LogError("[Counter] World ����!");
                return;
            }

            _entityManager = world.EntityManager;
            _counterEntity = _entityManager.CreateEntity();

            var position = transform.position;

            _entityManager.AddComponentData(_counterEntity,
                LocalTransform.FromPosition(position));

            _entityManager.AddComponentData(_counterEntity, new LocalToWorld
            {
                Value = float4x4.TRS(position, quaternion.identity, new float3(1))
            });

            // ���� StationComponent
            _entityManager.AddComponentData(_counterEntity, new StationComponent
            {
                Type = StationType.WorkBench, // �Ǵ� Counter Ÿ�� �ϳ� ���� �߰��ص� ��
                StationID = stationID,
                PlacedItemEntity = Entity.Null
            });

            // ī���� �±� + ����
            _entityManager.AddComponent<CounterStationTag>(_counterEntity);
            _entityManager.AddComponentData(_counterEntity, new CounterComponent
            {
                MaxItems = maxItems
            });

            // ī���� ���� ���� �غ�
            _entityManager.AddBuffer<CounterItemSlot>(_counterEntity);

            // ��ȣ�ۿ� ���� �±�
            _entityManager.AddComponentData(_counterEntity, new InteractableComponent
            {
                IsActive = true
            });
        }

        private void LateUpdate()
        {
            if (_entityManager.Exists(_counterEntity))
            {
                var lt = _entityManager.GetComponentData<LocalTransform>(_counterEntity);
                transform.position = lt.Position;
            }
        }

        private void OnDestroy()
        {
            if (World.DefaultGameObjectInjectionWorld == null ||
                !World.DefaultGameObjectInjectionWorld.IsCreated)
                return;

            var em = World.DefaultGameObjectInjectionWorld.EntityManager;

            if (em.Exists(_counterEntity))
            {
                em.DestroyEntity(_counterEntity);
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireCube(transform.position, colliderSize);
        }
    }
}
