using Unity.Entities;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using Meow.ECS.Components;

namespace Meow.ECS.Systems
{
    [UpdateInGroup(typeof(SimulationSystemGroup))]
    [UpdateAfter(typeof(StationRaycastDetectionSystem))]
    public partial class ContainerInteractionSystem : SystemBase
    {
        private EndSimulationEntityCommandBufferSystem _ecbSystem;
        private int _itemIdCounter = 1000;

        protected override void OnCreate()
        {
            base.OnCreate();
            _ecbSystem = World.GetOrCreateSystemManaged<EndSimulationEntityCommandBufferSystem>();
        }

        protected override void OnUpdate()
        {
            var ecb = _ecbSystem.CreateCommandBuffer();
            int currentItemId = _itemIdCounter;

            foreach (var (request, requestEntity) in
                     SystemAPI.Query<RefRO<InteractionRequestComponent>>()
                         .WithEntityAccess())
            {
                if (request.ValueRO.StationType != StationType.Container)
                {
                    ecb.DestroyEntity(requestEntity);
                    continue;
                }

                Entity playerEntity = request.ValueRO.PlayerEntity;
                Entity stationEntity = request.ValueRO.StationEntity;

                var playerStateRO = SystemAPI.GetComponentRO<PlayerStateComponent>(playerEntity);
                var container = SystemAPI.GetComponent<ContainerComponent>(stationEntity);

                Debug.Log("========================================");
                Debug.Log($"[�����̳� ��ȣ�ۿ�] ���: {container.ProvidedIngredient}");

                // ==========================================
                // 1. ��� �� ������ ������
                // ==========================================
                if (!playerStateRO.ValueRO.IsHoldingItem)
                {
                    Debug.Log($"[������ ������] {container.ProvidedIngredient}");

                    var playerTransform = SystemAPI.GetComponent<LocalTransform>(playerEntity);

                    Entity newItemEntity = ecb.CreateEntity();

                    // �⺻ ItemComponent
                    ecb.AddComponent(newItemEntity, new ItemComponent
                    {
                        ItemID = currentItemId++,
                        Type = ItemType.Ingredient,
                        State = ItemState.Raw,
                        IngredientType = container.ProvidedIngredient
                    });

                    // �� �� �ִ� ������
                    ecb.AddComponent(newItemEntity, new HoldableComponent
                    {
                        HolderEntity = playerEntity
                    });

                    // ��ġ
                    ecb.AddComponent(newItemEntity, new LocalTransform
                    {
                        Position = playerTransform.Position + new float3(0, 1.5f, 0.5f),
                        Rotation = quaternion.identity,
                        Scale = 1f
                    });

                    // �� Ÿ��/���� �±� (����)
                    ecb.AddComponent<IngredientTag>(newItemEntity);
                    ecb.AddComponent<RawItemTag>(newItemEntity);

                    // �� Meat �����̳��� ���� ���� ����/�±� �߰�
                    if (container.ProvidedIngredient == IngredientType.Meat)
                    {
                        ecb.AddComponent(newItemEntity, new CookableComponent
                        {
                            CookTime = 5f,  // ���߿� Blob/�����ͷ� ���� ��
                            BurnTime = 8f
                        });
                        ecb.AddComponent<BurnableTag>(newItemEntity);
                    }

                    // PlayerState ���� (ECB��)
                    var newPlayerState = playerStateRO.ValueRO;
                    newPlayerState.IsHoldingItem = true;
                    newPlayerState.HeldItemEntity = newItemEntity;
                    ecb.SetComponent(playerEntity, newPlayerState);

                    Debug.Log($"[����] {container.ProvidedIngredient} ȹ��! (ItemID: {currentItemId - 1})");
                }
                // ==========================================
                // 2. ������ ������� �� �ݳ� �õ� (���� ���� �״��)
                // ==========================================
                else
                {
                    var playerState = SystemAPI.GetComponentRW<PlayerStateComponent>(playerEntity);

                    Entity heldItemEntity = playerState.ValueRO.HeldItemEntity;

                    if (heldItemEntity == Entity.Null)
                    {
                        Debug.LogWarning("[����] IsHoldingItem=true�ε� HeldItemEntity�� Null!");
                        ecb.DestroyEntity(requestEntity);
                        Debug.Log("========================================");
                        continue;
                    }

                    if (!SystemAPI.HasComponent<ItemComponent>(heldItemEntity))
                    {
                        Debug.LogWarning("[����] HeldItemEntity�� ItemComponent�� ����!");
                        ecb.DestroyEntity(requestEntity);
                        Debug.Log("========================================");
                        continue;
                    }

                    var heldItem = SystemAPI.GetComponent<ItemComponent>(heldItemEntity);

                    Debug.Log($"[�ݳ� �õ�] ����ִ� ������: {heldItem.IngredientType} (����: {heldItem.State})");

                    bool isMatchingType = heldItem.IngredientType == container.ProvidedIngredient;
                    bool isRawState = heldItem.State == ItemState.Raw;
                    bool canReturn = container.AllowReturn;

                    Debug.Log($"[�ݳ� �˻�] Ÿ����ġ:{isMatchingType} | Raw����:{isRawState} | �ݳ����:{canReturn}");

                    if (isMatchingType && isRawState && canReturn)
                    {
                        ecb.DestroyEntity(heldItemEntity);

                        playerState.ValueRW.IsHoldingItem = false;
                        playerState.ValueRW.HeldItemEntity = Entity.Null;

                        Debug.Log($"[����] {heldItem.IngredientType} �ݳ� �Ϸ�!");
                    }
                    else
                    {
                        if (!canReturn)
                            Debug.Log("[����] �� �����̳ʴ� �ݳ��� ������� �ʽ��ϴ�.");
                        else if (!isMatchingType)
                            Debug.Log($"[����] Ÿ�� ����ġ! �� �����̳ʴ� {container.ProvidedIngredient}�� �޽��ϴ�.");
                        else if (!isRawState)
                            Debug.Log($"[����] Raw ���� �����۸� �ݳ� �����մϴ�. (����: {heldItem.State})");
                    }
                }

                Debug.Log("========================================");
                ecb.DestroyEntity(requestEntity);
            }

            _itemIdCounter = currentItemId;
        }
    }
}
