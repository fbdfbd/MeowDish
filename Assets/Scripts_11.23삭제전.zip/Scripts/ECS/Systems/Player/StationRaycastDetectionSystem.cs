using Unity.Entities;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Meow.ECS.Components;
using RaycastHit = Unity.Physics.RaycastHit;

namespace Meow.ECS.Systems
{
    /// <summary>
    /// Raycast ��� �����̼� ���� �ý���
    /// </summary>
    [UpdateInGroup(typeof(SimulationSystemGroup))]
    public partial struct StationRaycastDetectionSystem : ISystem
    {
        public void OnUpdate(ref SystemState state)
        {
            if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsWorldSingleton))
            {
                Debug.LogWarning("[StationRaycast] PhysicsWorld ���� �غ� �� ��!");
                return;
            }

            var physicsWorld = physicsWorldSingleton.PhysicsWorld;


            foreach (var (playerState, playerTransform, playerEntity) in
                     SystemAPI.Query<RefRW<PlayerStateComponent>, RefRO<LocalTransform>>()
                     .WithEntityAccess())
            {
                float3 rayDirection = playerState.ValueRO.LastMoveDirection;

                if (math.lengthsq(rayDirection) < 0.01f)
                {
                    rayDirection = new float3(0, 0, 1);
                }
                else
                {
                    rayDirection = math.normalize(rayDirection);
                }

                float interactionRange = 2.0f;

                float3 rayStart = playerTransform.ValueRO.Position;
                rayStart.y = 0.5f;

                float3 rayEnd = rayStart + rayDirection * interactionRange;

                var raycastInput = new RaycastInput
                {
                    Start = rayStart,
                    End = rayEnd,
                    Filter = new CollisionFilter
                    {
                        BelongsTo = 1u << 0,
                        CollidesWith = 1u << 6,
                        GroupIndex = 0
                    }
                };

                Debug.DrawLine(rayStart, rayEnd, Color.yellow, 0.5f);

                if (physicsWorld.CastRay(raycastInput, out RaycastHit hit))
                {
                    Debug.Log($"? [HIT!] Entity: {hit.Entity}");
                    Debug.DrawLine(rayStart, hit.Position, Color.green, 0.5f);

                    playerState.ValueRW.CurrentStationEntity = hit.Entity;
                    playerState.ValueRW.IsNearStation = true;
                }
                else
                {
                    Debug.Log($"? [MISS]");
                    Debug.DrawLine(rayStart, rayEnd, Color.red, 0.5f);

                    playerState.ValueRW.CurrentStationEntity = Entity.Null;
                    playerState.ValueRW.IsNearStation = false;
                }

            }
        }

    }
}



/*
��ü : Burst����
using Unity.Entities;
using Unity.Physics;
using Unity.Mathematics;
using Unity.Transforms;
using Unity.Burst; // Burst ���ӽ����̽� �߰�
using Meow.ECS.Components;
using RaycastHit = Unity.Physics.RaycastHit;

namespace Meow.ECS.Systems
{
    /// <summary>
    /// Raycast ��� �����̼� ���� �ý���
    /// </summary>
    [UpdateInGroup(typeof(SimulationSystemGroup), OrderLast = true)]
    [BurstCompile] // �ý��� ��ü�� Burst ����
    public partial struct StationRaycastDetectionSystem : ISystem
    {
        [BurstCompile] // OnUpdate�� Burst ����
        public void OnUpdate(ref SystemState state)
        {
            // PhysicsWorldSingleton�� ������ �ƹ��͵� ���� ����
            if (!SystemAPI.TryGetSingleton<PhysicsWorldSingleton>(out var physicsWorldSingleton))
            {
                return;
            }

            var physicsWorld = physicsWorldSingleton.PhysicsWorld;

            // Player ���� �� Raycast ó��
            foreach (var (playerState, playerTransform) in
                     SystemAPI.Query<RefRW<PlayerStateComponent>, RefRO<LocalTransform>>())
            {
                float3 rayDirection = playerState.ValueRO.LastMoveDirection;

                // ���� ���� ��ȿ�� �˻� (���̰� �ʹ� ª���� �⺻�� Z��)
                if (math.lengthsq(rayDirection) < 0.01f)
                {
                    rayDirection = new float3(0, 0, 1);
                }
                else
                {
                    rayDirection = math.normalize(rayDirection);
                }

                float interactionRange = 2.0f;
                float3 rayStart = playerTransform.ValueRO.Position;
                rayStart.y = 0.5f; // ���� ����

                float3 rayEnd = rayStart + (rayDirection * interactionRange);

                var raycastInput = new RaycastInput
                {
                    Start = rayStart,
                    End = rayEnd,
                    Filter = new CollisionFilter
                    {
                        BelongsTo = 1u << 0,   // Player ���̾� (����)
                        CollidesWith = 1u << 6, // Station ���̾� (����)
                        GroupIndex = 0
                    }
                };

                // Raycast ����
                if (physicsWorld.CastRay(raycastInput, out RaycastHit hit))
                {
                    playerState.ValueRW.CurrentStationEntity = hit.Entity;
                    playerState.ValueRW.IsNearStation = true;
                }
                else
                {
                    playerState.ValueRW.CurrentStationEntity = Entity.Null;
                    playerState.ValueRW.IsNearStation = false;
                }
            }
        }
    }
}







*/

