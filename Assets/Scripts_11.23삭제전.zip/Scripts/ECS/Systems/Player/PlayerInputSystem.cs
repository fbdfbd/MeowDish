using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using Meow.ECS.Components;
using Meow.ScriptableObjects;

namespace Meow.ECS.Systems
{
    /// <summary>
    /// ScriptableObject�� ���� �Է� ó��
    /// </summary>
    [UpdateInGroup(typeof(SimulationSystemGroup), OrderFirst = true)]
    public partial class PlayerInputSystem : SystemBase
    {
        // ? ScriptableObject ����
        private InputReferences _inputReferences;

        protected override void OnCreate()
        {
            RequireForUpdate<PlayerInputComponent>();

            // ? Resources �������� �ε�
            _inputReferences = Resources.Load<InputReferences>("InputReferences");

            if (_inputReferences == null)
            {
                Debug.LogError("[PlayerInputSystem] InputReferences not found in Resources folder! " +
                    "Create it at 'Assets/Resources/InputReferences.asset'");
            }
            else
            {
                Debug.Log("[PlayerInputSystem] InputReferences loaded successfully!");
            }
        }

        protected override void OnUpdate()
        {
            // ========================================
            // 1. �̵� �Է�
            // ========================================
            float2 input = float2.zero;

            // ? ScriptableObject�� ���� ����
            if (_inputReferences != null && _inputReferences.joystick != null)
            {
                Vector2 joystickInput = _inputReferences.joystick.InputVector;
                input = new float2(joystickInput.x, joystickInput.y);
            }

            // Ű���� �Է� (�׽�Ʈ��)
            if (Input.GetKey(KeyCode.W)) input.y = 1;
            if (Input.GetKey(KeyCode.S)) input.y = -1;
            if (Input.GetKey(KeyCode.A)) input.x = -1;
            if (Input.GetKey(KeyCode.D)) input.x = 1;

            // ========================================
            // 2. ��ȣ�ۿ� �Է� (Tap + Hold)
            // ========================================
            bool interactTapped = false;
            bool interactHoldStarted = false;
            bool interactHolding = false;

            // ? ScriptableObject�� ���� ����
            if (_inputReferences != null && _inputReferences.interactionButton != null)
            {
                interactTapped = _inputReferences.interactionButton.WasTappedThisFrame;
                interactHoldStarted = _inputReferences.interactionButton.WasHoldStartedThisFrame;
                interactHolding = _inputReferences.interactionButton.IsHolding;

                if (interactTapped)
                {
                    Debug.Log("[PlayerInputSystem] TAP detected!");
                }
                if (interactHoldStarted)
                {
                    Debug.Log("[PlayerInputSystem] HOLD STARTED!");
                }
            }

            // Ű���� �Է� (�׽�Ʈ��)
            if (Input.GetKeyDown(KeyCode.E))
            {
                interactTapped = true;
            }
            if (Input.GetKey(KeyCode.E))
            {
                interactHolding = true;
            }

            // ========================================
            // 3. ECS�� ����
            // ========================================
            Entities.ForEach((ref PlayerInputComponent playerInput) =>
            {
                playerInput.MoveInput = input;
                playerInput.InteractTapped = interactTapped;
                playerInput.InteractHoldStarted = interactHoldStarted;
                playerInput.InteractHolding = interactHolding;
            }).WithoutBurst().Run();
        }
    }
}