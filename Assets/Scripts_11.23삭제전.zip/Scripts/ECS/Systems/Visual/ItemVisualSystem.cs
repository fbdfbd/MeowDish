using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Meow.ECS.Components;
using System.Collections.Generic;

namespace Meow.ECS.Systems
{
    /// <summary>
    /// ������ Entity�� �ð��� GameObject ����
    /// ��� �ִ� �������� �÷��̾� ����ٴ�
    /// </summary>
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class ItemVisualSystem : SystemBase
    {
        // Entity�� GameObject ����
        private Dictionary<Entity, GameObject> itemVisuals = new Dictionary<Entity, GameObject>();

        protected override void OnUpdate()
        {
            var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);

            // ????????????????????????????????????????
            // 1. ���ο� ������ Entity�� GameObject ����
            // ????????????????????????????????????????
            Entities
                .WithAll<ItemComponent, HoldableComponent>()
                .WithNone<ItemVisualTag>()  // ���� �ð�ȭ �� �� �͸�
                .ForEach((Entity itemEntity, in ItemComponent item) =>
                {
                    // GameObject ����
                    GameObject visual = CreateItemVisual(item);
                    itemVisuals[itemEntity] = visual;

                    // Tag �߰� (�ߺ� ���� ����)
                    ecb.AddComponent<ItemVisualTag>(itemEntity);

                    Debug.Log($"[ItemVisualSystem] Created visual for {item.IngredientType}");

                }).WithoutBurst().Run();

            // ????????????????????????????????????????
            // 2. ������ ��ġ ������Ʈ
            // ????????????????????????????????????????
            Entities
                .WithAll<ItemComponent, HoldableComponent, ItemVisualTag>()
                .ForEach((Entity itemEntity, in LocalTransform itemTransform, in HoldableComponent holdable) =>
                {
                    if (itemVisuals.TryGetValue(itemEntity, out GameObject visual))
                    {
                        if (visual != null)
                        {
                            // ����ִ� ��� - �÷��̾� ���� ǥ��
                            if (holdable.IsHeld && SystemAPI.Exists(holdable.HolderEntity))
                            {
                                var holderTransform = SystemAPI.GetComponent<LocalTransform>(holdable.HolderEntity);
                                visual.transform.position = holderTransform.Position + new float3(0, 1.5f, 0.5f);
                                visual.SetActive(true);
                            }
                            // �� ����ִ� ��� - ������ ��ü ��ġ
                            else
                            {
                                visual.transform.position = itemTransform.Position;
                                visual.SetActive(true);
                            }
                        }
                    }
                }).WithoutBurst().Run();

            // ????????????????????????????????????????
            // 3. ������ Entity�� GameObject ����
            // ????????????????????????????????????????
            var entitiesToRemove = new List<Entity>();
            foreach (var kvp in itemVisuals)
            {
                if (!SystemAPI.Exists(kvp.Key))
                {
                    if (kvp.Value != null)
                        GameObject.Destroy(kvp.Value);
                    entitiesToRemove.Add(kvp.Key);
                }
            }

            foreach (var entity in entitiesToRemove)
            {
                itemVisuals.Remove(entity);
            }

            ecb.Playback(EntityManager);
            ecb.Dispose();
        }

        private GameObject CreateItemVisual(ItemComponent item)
        {
            GameObject visual = null;

            // ��� Ÿ�Ժ� �ð��� ǥ��
            switch (item.IngredientType)
            {
                case IngredientType.Bread:
                    visual = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    visual.transform.localScale = Vector3.one * 0.3f;
                    visual.GetComponent<Renderer>().material.color = new Color(0.9f, 0.7f, 0.4f);
                    break;

                case IngredientType.Meat:
                    visual = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    visual.transform.localScale = Vector3.one * 0.4f;
                    visual.GetComponent<Renderer>().material.color = new Color(0.8f, 0.2f, 0.2f);
                    break;

                case IngredientType.Lettuce:
                    visual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                    visual.transform.localScale = new Vector3(0.4f, 0.1f, 0.4f);
                    visual.GetComponent<Renderer>().material.color = new Color(0.2f, 0.8f, 0.2f);
                    break;

                case IngredientType.Tomato:
                    visual = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    visual.transform.localScale = Vector3.one * 0.3f;
                    visual.GetComponent<Renderer>().material.color = new Color(1f, 0.3f, 0.3f);
                    break;

                case IngredientType.Cheese:
                    visual = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    visual.transform.localScale = new Vector3(0.3f, 0.1f, 0.3f);
                    visual.GetComponent<Renderer>().material.color = new Color(1f, 0.9f, 0.3f);
                    break;

                case IngredientType.Plate:
                    visual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                    visual.transform.localScale = new Vector3(0.5f, 0.05f, 0.5f);
                    visual.GetComponent<Renderer>().material.color = Color.white;
                    break;

                default:
                    visual = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    visual.transform.localScale = Vector3.one * 0.3f;
                    visual.GetComponent<Renderer>().material.color = Color.magenta;
                    break;
            }

            // Collider ���� (�÷��̾�� �浹 ����)
            var collider = visual.GetComponent<Collider>();
            if (collider != null)
                GameObject.Destroy(collider);

            visual.name = $"Item_{item.IngredientType}_{item.ItemID}";

            // ���º� �߰� ȿ��
            if (item.State == ItemState.Chopped)
            {
                // �丰 ǥ�� - ũ�� ���̱�
                visual.transform.localScale *= 0.8f;
            }
            else if (item.State == ItemState.Cooked)
            {
                // ���� ǥ�� - �� ��Ӱ�
                var renderer = visual.GetComponent<Renderer>();
                renderer.material.color *= 0.7f;
            }

            return visual;
        }

        protected override void OnDestroy()
        {
            // �ý��� ���� �� ��� GameObject ����
            foreach (var kvp in itemVisuals)
            {
                if (kvp.Value != null)
                    GameObject.Destroy(kvp.Value);
            }
            itemVisuals.Clear();
        }
    }

    /// <summary>
    /// �������� �ð�ȭ�Ǿ����� ǥ���ϴ� �±�
    /// </summary>
    public struct ItemVisualTag : IComponentData { }
}