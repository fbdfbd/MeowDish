using UnityEngine;
using Meow.ScriptableObjects;
using Meow.UI;

namespace Meow.Managers
{
    /// <summary>
    /// ���� UI�� InputReferences�� �ڵ� ����
    /// </summary>
    public class InputReferencesManager : MonoBehaviour
    {
        [Header("ScriptableObject")]
        [Tooltip("Project���� ���� InputReferences ����")]
        [SerializeField] private InputReferences inputReferences;

        [Header("Auto Find Settings")]
        [SerializeField] private bool autoFindOnStart = true;

        private void Start()
        {
            if (autoFindOnStart)
            {
                FindAndAssignReferences();
            }
        }

        /// <summary>
        /// ������ UI ������Ʈ�� ã�Ƽ� ScriptableObject�� �Ҵ�
        /// </summary>
        public void FindAndAssignReferences()
        {
            if (inputReferences == null)
            {
                Debug.LogError("[InputReferencesManager] InputReferences asset is not assigned!");
                return;
            }

            // VirtualJoystick ã��
            var joystick = FindFirstObjectByType<VirtualJoystick>();
            if (joystick != null)
            {
                inputReferences.joystick = joystick;
                Debug.Log("[InputReferencesManager] ? VirtualJoystick assigned");
            }
            else
            {
                Debug.LogWarning("[InputReferencesManager] ? VirtualJoystick not found in scene");
            }

            // InteractionButton ã��
            var button = FindFirstObjectByType<InteractionButton>();
            if (button != null)
            {
                inputReferences.interactionButton = button;
                Debug.Log("[InputReferencesManager] ? InteractionButton assigned");
            }
            else
            {
                Debug.LogWarning("[InputReferencesManager] ? InteractionButton not found in scene");
            }

            inputReferences.LogStatus();
        }

        private void OnDestroy()
        {
            // ? �� ���� �� ���� ���� (�߿�!)
            if (inputReferences != null)
            {
                inputReferences.joystick = null;
                inputReferences.interactionButton = null;
            }
        }

#if UNITY_EDITOR
        // ? Inspector���� ��ư���� �׽�Ʈ ����
        [ContextMenu("Find And Assign References")]
        private void EditorFindReferences()
        {
            FindAndAssignReferences();
        }
#endif
    }
}